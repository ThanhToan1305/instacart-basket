"""Tiện ích dùng chung."""
